---
layout: page
title: Configuration Variables
parent_title: Configuration
permalink: /configuration/configuration-variables.html
modification_time: 2015-08-05T11:59:41+00:00
---

Refer to *Reference* >> *mPDF Variables* >> *<a href="{{ "/reference/mpdf-variables/overview.html" | prepend: site.baseurl }}">Overview</a>*

