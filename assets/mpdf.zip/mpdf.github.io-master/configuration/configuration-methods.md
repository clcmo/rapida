---
layout: page
title: Configuration Methods
parent_title: Configuration
permalink: /configuration/configuration-methods.html
modification_time: 2015-08-05T11:59:40+00:00
---

Refer to *Reference* >> *mPDF Functions* >> *<a href="{{ "/reference/mpdf-functions/overview.html" | prepend: site.baseurl }}">Overview</a>*

