---
layout: page
title: Text is replaced
parent_title: Troubleshooting
permalink: /troubleshooting/text-is-replaced.html
modification_time: 2015-08-05T12:00:30+00:00
---

If some of your text is unexpectedly replaced by numbers or date-strings, check 
<a href="{{ "/what-else-can-i-do/replaceable-aliases.html" | prepend: site.baseurl }}">Replaceable Aliases</a>.

