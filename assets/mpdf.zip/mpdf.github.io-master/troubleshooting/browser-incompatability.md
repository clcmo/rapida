---
layout: page
title: Browser incompatability
parent_title: Troubleshooting
permalink: /troubleshooting/browser-incompatability.html
modification_time: 2015-08-05T12:00:31+00:00
---

If you wish to pass the same HTML to a browser as to mPDF, and it is showing incorrectly in the browser, please see 
<a href="{{ "/html-support/custom-html-tags.html" | prepend: site.baseurl }}">Custom tags</a>.

