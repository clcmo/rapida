---
layout: page
title: Copyright
permalink: /copyright.html
---

Copyright © 2015 Ian N Back This material may be distributed only subject to the terms and conditions set forth in the Open Publication License, v1.0 or later.

Distribution of substantively modified versions of this document is prohibited without the explicit permission of the copyright holder.

Distribution of the work or derivative of the work in any standard (paper) book form is prohibited unless prior permission is obtained from the copyright holder.

<http://www.opencontent.org/openpub/>
