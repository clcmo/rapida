> Please use https://stackoverflow.com/questions/tagged/mpdf for all your general questions or troubleshooting!
> 
> Submit here ONLY issues about mPDF DOCUMENTATION. For mPDF issues and feature requests see: https://github.com/mpdf/mpdf/issues
>
> Guideline: https://github.com/mpdf/mpdf/blob/development/.github/CONTRIBUTING.md
