---
layout: page
title: Useful links
parent_title: Codepages & Glyphs
permalink: /reference/codepages-glyphs/useful-links.html
modification_time: 2015-08-05T12:03:02+00:00
---

Fonts frequency (browsers)

<ul>
<li><a href="http://www.codestyle.org/css/font-family/sampler-CombinedResults.shtml">http://www.codestyle.org/css/font-family/sampler-CombinedResults.shtml</a></li>
</ul>

Coverage of FreeSans fonts

<ul>
<li><a href="http://www.gnu.org/software/freefont/coverage.html">http://www.gnu.org/software/freefont/coverage.html</a></li>
</ul>

Coverage of DejaVu fonts (enclosed files in downloads)

<ul>
<li><a href="http://sourceforge.net/projects/dejavu/">http://sourceforge.net/projects/dejavu/</a></li>
</ul>
