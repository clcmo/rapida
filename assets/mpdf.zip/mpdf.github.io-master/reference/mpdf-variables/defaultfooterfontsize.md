---
layout: page
title: defaultfooterfontsize
parent_title: mPDF Variables
permalink: /reference/mpdf-variables/defaultfooterfontsize.html
modification_time: 2015-08-05T12:01:51+00:00
---

