---
layout: page
title: smCapsStretch
parent_title: mPDF Variables
permalink: /reference/mpdf-variables/smcapsstretch.html
modification_time: 2015-08-05T12:02:30+00:00
---

mPDF &ge; 5.0

Control SmallCaps appearance

Default set as a <a href="{{ "/configuration/configuration-v7-x.html" | prepend: site.baseurl }}">configuration variable</a>

Default value: `115`   

% to stretch small caps horizontally

