---
layout: page
title: crossMarkMargin
parent_title: mPDF Variables
permalink: /reference/mpdf-variables/crossmarkmargin.html
modification_time: 2015-08-05T12:01:48+00:00
---

mPDF &ge; 5.1

Distance of cross mark from margin in mm

Default set as a <a href="{{ "/configuration/configuration-v7-x.html" | prepend: site.baseurl }}">configuration variable</a>

Default value: `5`

