---
layout: page
title: ignore_table_percents
parent_title: mPDF Variables
permalink: /reference/mpdf-variables/ignore-table-percents.html
modification_time: 2015-08-05T12:02:01+00:00
---

