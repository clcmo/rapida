---
layout: page
title: ignore_invalid_utf8
parent_title: mPDF Variables
permalink: /reference/mpdf-variables/ignore-invalid-utf8.html
modification_time: 2015-08-05T12:02:00+00:00
---

