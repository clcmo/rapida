---
layout: page
title: printers_info
parent_title: mPDF Variables
permalink: /reference/mpdf-variables/printers-info.html
modification_time: 2015-08-05T12:02:20+00:00
---

mPDF &ge; 5.1

Adds date and page info for printer when using `@page` and `marks:crop;`

Default set as a <a href="{{ "/configuration/configuration-v7-x.html" | prepend: site.baseurl }}">configuration variable</a>


Values: `true`\|`false`

Default value: `false`
