---
layout: page
title: debugfonts
parent_title: mPDF Variables
permalink: /reference/mpdf-variables/debugfonts.html
modification_time: 2015-08-05T12:01:50+00:00
---


mPDF &ge; 5.0

Show errors and warning notes for fonts.

Default set as a <a href="{{ "/configuration/configuration-v7-x.html" | prepend: site.baseurl }}">configuration variable</a>

Default value: `false`

Values:
* `true`
* `false`


