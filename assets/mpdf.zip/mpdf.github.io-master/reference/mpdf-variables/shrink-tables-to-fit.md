---
layout: page
title: shrink_tables_to_fit
parent_title: mPDF Variables
permalink: /reference/mpdf-variables/shrink-tables-to-fit.html
modification_time: 2015-08-05T12:02:27+00:00
---

