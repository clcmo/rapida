---
layout: page
title: defaultheaderfontsize
parent_title: mPDF Variables
permalink: /reference/mpdf-variables/defaultheaderfontsize.html
modification_time: 2015-08-05T12:01:52+00:00
---

