---
layout: page
title: defaultheaderfontstyle
parent_title: mPDF Variables
permalink: /reference/mpdf-variables/defaultheaderfontstyle.html
modification_time: 2015-08-05T12:01:53+00:00
---

