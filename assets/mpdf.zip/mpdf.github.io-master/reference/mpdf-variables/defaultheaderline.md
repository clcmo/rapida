---
layout: page
title: defaultheaderline
parent_title: mPDF Variables
permalink: /reference/mpdf-variables/defaultheaderline.html
modification_time: 2015-08-05T12:01:53+00:00
---

