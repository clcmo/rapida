---
layout: page
title: jSmaxChar
parent_title: mPDF Variables
permalink: /reference/mpdf-variables/jsmaxchar.html
modification_time: 2015-08-05T12:02:03+00:00
---

Maximum spacing to allocate to character spacing. (`0` = no maximum)

Set as a <a href="{{ "/configuration/configuration-v7-x.html" | prepend: site.baseurl }}">configuration variable</a>

Default value: `2`

