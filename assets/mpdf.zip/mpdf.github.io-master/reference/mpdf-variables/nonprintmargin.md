---
layout: page
title: nonPrintMargin
parent_title: mPDF Variables
permalink: /reference/mpdf-variables/nonprintmargin.html
modification_time: 2015-08-05T12:02:15+00:00
---

mPDF &ge; 5.1

Non-printable border at edge of paper sheet in mm

Default set as a <a href="{{ "/configuration/configuration-v7-x.html" | prepend: site.baseurl }}">configuration variable</a>

Default value: `8`

When using Crop- and cross-marks in `@page` media

