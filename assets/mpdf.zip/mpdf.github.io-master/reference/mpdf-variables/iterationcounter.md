---
layout: page
title: iterationCounter
parent_title: mPDF Variables
permalink: /reference/mpdf-variables/iterationcounter.html
modification_time: 2015-08-05T12:02:03+00:00
---

mPDF &ge; 5.0

Allow use of `{iteration varname}` in THEAD

Default set as a <a href="{{ "/configuration/configuration-v7-x.html" | prepend: site.baseurl }}">configuration variable</a>


Values: `true`\|`false`

Default value: `false`




See also:

* <a href="{{ "/what-else-can-i-do/replaceable-aliases.html" | prepend: site.baseurl }}">Replaceable Aliases</a>
