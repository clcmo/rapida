---
layout: page
title: defaultfooterfontstyle
parent_title: mPDF Variables
permalink: /reference/mpdf-variables/defaultfooterfontstyle.html
modification_time: 2015-08-05T12:01:51+00:00
---

