---
layout: page
title: cropMarkLength
parent_title: mPDF Variables
permalink: /reference/mpdf-variables/cropmarklength.html
modification_time: 2015-08-05T12:01:47+00:00
---

mPDF &ge; 5.1

Default length in mm of crop line

Default set as a <a href="{{ "/configuration/configuration-v7-x.html" | prepend: site.baseurl }}">configuration variable</a>

Default value: `18`

