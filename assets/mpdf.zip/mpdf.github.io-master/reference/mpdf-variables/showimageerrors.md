---
layout: page
title: showImageErrors
parent_title: mPDF Variables
permalink: /reference/mpdf-variables/showimageerrors.html
modification_time: 2015-08-05T12:02:25+00:00
---

mPDF &ge; 3.0

Set to `true` for optional error reporting for problems with Images.

