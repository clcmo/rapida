---
layout: page
title: watermarkAngle
parent_title: mPDF Variables
permalink: /reference/mpdf-variables/watermarkangle.html
modification_time: 2017-09-25T19:02:40+00:00
---

(mPDF &ge; 1.0)

# Description

int **watermarkAngle**

Specifies angle of the watermark to use in the document
