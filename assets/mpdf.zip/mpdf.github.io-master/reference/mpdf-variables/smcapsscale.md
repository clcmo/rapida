---
layout: page
title: smCapsScale
parent_title: mPDF Variables
permalink: /reference/mpdf-variables/smcapsscale.html
modification_time: 2015-08-05T12:02:29+00:00
---

mPDF &ge; 5.0

Control SmallCaps appearance

Default set as a <a href="{{ "/configuration/configuration-v7-x.html" | prepend: site.baseurl }}">configuration variable</a>

Default value: `0.75`   

Factor of `1` to scale capital letters

