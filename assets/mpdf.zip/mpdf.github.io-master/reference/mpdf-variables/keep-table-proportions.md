---
layout: page
title: keep_table_proportions
parent_title: mPDF Variables
permalink: /reference/mpdf-variables/keep-table-proportions.html
modification_time: 2015-08-05T12:02:06+00:00
---

If table width is set, and is > page width, setting this value to `true` forces the table to keep relative sizes when resizing.

It also forces respect of cell widths set by `%`

Default: `true`