---
layout: page
title: footer_line_spacing
parent_title: mPDF Variables
permalink: /reference/mpdf-variables/footer-line-spacing.html
modification_time: 2015-08-05T12:01:56+00:00
---

