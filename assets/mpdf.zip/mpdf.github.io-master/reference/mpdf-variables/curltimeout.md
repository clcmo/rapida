---
layout: page
title: curlTimeout
parent_title: mPDF Variables
permalink: /reference/mpdf-variables/curltimeout.html
modification_time: 2017-09-30T11:03:32+00:00
---

(mPDF &ge; 7.0)

# Description

int **curlTimeout** (default `5`)

Number of seconds for cURL requests to timeout after
