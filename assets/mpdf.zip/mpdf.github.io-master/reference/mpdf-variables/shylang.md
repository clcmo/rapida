---
layout: page
title: SHYlang
parent_title: mPDF Variables
permalink: /reference/mpdf-variables/shylang.html
modification_time: 2015-08-05T12:02:28+00:00
---

(mPDF &ge; 2.5)

Please see <a href="{{ "/what-else-can-i-do/hyphenation.html" | prepend: site.baseurl }}">Hyphenation</a>.

