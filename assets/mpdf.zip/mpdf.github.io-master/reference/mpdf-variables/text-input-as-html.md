---
layout: page
title: text_input_as_HTML
parent_title: mPDF Variables
permalink: /reference/mpdf-variables/text-input-as-html.html
modification_time: 2015-08-05T12:02:33+00:00
---

