---
layout: page
title: header_line_spacing
parent_title: mPDF Variables
permalink: /reference/mpdf-variables/header-line-spacing.html
modification_time: 2015-08-05T12:01:58+00:00
---

