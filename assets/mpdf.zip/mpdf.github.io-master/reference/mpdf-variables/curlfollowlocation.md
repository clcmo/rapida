---
layout: page
title: curlFollowLocation
parent_title: mPDF Variables
permalink: /reference/mpdf-variables/curlfollowlocation.html
modification_time: 2017-09-30T11:03:32+00:00
---

(mPDF &ge; 7.0)

# Description

boolean **curlFollowLocation** (default `false`)

If set to `true`, follow redirects for cURL requests
