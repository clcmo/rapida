---
layout: page
title: jSWord
parent_title: mPDF Variables
permalink: /reference/mpdf-variables/jsword.html
modification_time: 2015-08-05T12:02:05+00:00
---

float **$jSword**

Proportion (/1) of space (when justifying margins) to allocate to Word vs. Character

Default: `0.4`