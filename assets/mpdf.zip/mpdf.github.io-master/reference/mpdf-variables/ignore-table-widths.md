---
layout: page
title: ignore_table_widths
parent_title: mPDF Variables
permalink: /reference/mpdf-variables/ignore-table-widths.html
modification_time: 2015-08-05T12:02:01+00:00
---

