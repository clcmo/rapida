---
layout: page
title: CJK Languages
parent_title: Fonts & Languages
permalink: /fonts-languages/cjk-languages.html
modification_time: 2015-08-05T11:59:35+00:00
---

In order to view a file with non-embedded CJK (chinese-japanese-korean) fonts, you - and other users - 
need to download the Asian font pack for Adobe Reader for the languages: 
 * Chinese (Simplified), 
 * Chinese (Traditional), 
 * Korean, 
 * and Japanese 
 
 from [http://www.adobe.com/support/downloads/product.jsp?platform=windows&product=10](http://www.adobe.com/support/downloads/product.jsp?platform=windows&product=10)

