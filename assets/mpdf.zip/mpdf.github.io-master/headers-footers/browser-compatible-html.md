---
layout: page
title: Browser compatible HTML
parent_title: Headers & Footers
permalink: /headers-footers/browser-compatible-html.html
modification_time: 2015-08-05T11:59:55+00:00
---

If you wish to pass the same HTML to a browser as to mPDF, and it is showing incorrectly in the browser, 
please see <a href="{{ "/html-support/custom-html-tags.html" | prepend: site.baseurl }}">Custom tags</a>.

